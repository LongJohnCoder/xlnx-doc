Xilinx 14.5 Open Source solution release

See http://wiki.xilinx.com/zynq-release-14-5 for details about the release.

The following command line was used with bootgen to create the BOOT.BIN.

bootgen -image boot.bif -o i BOOT.BIN


